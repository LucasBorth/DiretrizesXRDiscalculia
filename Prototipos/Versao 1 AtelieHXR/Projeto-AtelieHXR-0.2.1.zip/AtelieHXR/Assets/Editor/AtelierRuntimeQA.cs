using System;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using MatematicaHXR.Atelier;
namespace MatematicaHXR.Editor
{
 [InitializeOnLoad]
 public static class AtelierRuntimeQA
 {
  static double due; static int phase; static AtelierExperience e; static Vector3 pausedPosition; static int frame;
  static AtelierRuntimeQA(){EditorApplication.update+=Tick;}
  [MenuItem("HXR/Ateliê/4 - Testar interação em execução")]
  public static void Start(){if(EditorApplication.isPlaying)return;EditorSceneManager.OpenScene(AtelierBuild.ScenePath);SessionState.SetBool("AtelierRuntimeQA",true);SessionState.SetInt("AtelierPhase",0);EditorApplication.isPlaying=true;}
  static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
  static void Tick()
  {
   if(!SessionState.GetBool("AtelierRuntimeQA",false)||!EditorApplication.isPlaying||EditorApplication.isCompiling||EditorApplication.timeSinceStartup<due)return;
   due=EditorApplication.timeSinceStartup+.4;
   try{
    e=UnityEngine.Object.FindAnyObjectByType<AtelierExperience>();if(e==null||!e.Ready)return;
    phase=SessionState.GetInt("AtelierPhase",0);
    var b=e.Blocks[0];
    if(phase==0){typeof(AtelierExperience).GetField("soundLevel",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(e,0f);Check(e.Blocks.Count==15,"Quantidade física incorreta");frame=e.FrameTicks;b.transform.position+=Vector3.up*.2f;due=EditorApplication.timeSinceStartup+1.8;}
    if(phase==1){Check(e.FrameTicks>frame+10,"Player loop não avança");Check(b.transform.localPosition.y>.73f&&b.transform.localPosition.y<.84f,"Bloco não repousou sobre a mesa");e.TogglePause();pausedPosition=b.transform.position;}
    if(phase==2){Check(e.Paused&&Vector3.Distance(b.transform.position,pausedPosition)<.001f,"Pausa não estabilizou física");e.TogglePause();b.transform.position+=Vector3.down*3;}
    if(phase==3){Check(b.transform.localPosition.y>.70f,"Recuperação após queda falhou");e.Model.Practice();e.Primary();Check(e.Model.Left==15,"Grupos não começaram em 15+0");
     var pick=typeof(AtelierExperience).GetMethod("Pick",BindingFlags.Instance|BindingFlags.NonPublic);
     var drop=typeof(AtelierExperience).GetMethod("Drop",BindingFlags.Instance|BindingFlags.NonPublic);
     var ray=new Ray(b.transform.position-Vector3.forward*.3f,Vector3.forward);
     pick.Invoke(e,new object[]{b,0,false,ray});Check(b.HeldBy==0&&b.Body.isKinematic,"Pegar não vinculou unidade");
     pick.Invoke(e,new object[]{b,1,true,ray});Check(b.HeldBy==0,"Duas mãos tomaram a mesma unidade");
     b.transform.localPosition=e.Slot(1,0);drop.Invoke(e,new object[]{0});Check(e.Model.Left==14&&e.Model.Right==1&&b.HeldBy==-1,"Soltar em B não transferiu unidade");
     e.Model.Begin();e.Organize();}
    if(phase==4){
     for(int step=0;step<=15;step++){
      Check(e.Model.Left==15-step,"Sequência incorreta em runtime");e.Primary();
      for(int i=0;i<15;i++){var unit=e.Blocks[i];unit.transform.localPosition=e.Slot(2,i);e.CompleteDrop(unit);}
      Check(e.Model.Phase==AtelierModel.Stage.Result&&e.Model.Joined==15,"União física não concluiu a soma");
      if(step<15){e.Primary();int id=Array.FindIndex(e.Model.Group,g=>g==0);var unit=e.Blocks[id];unit.transform.localPosition=e.Slot(1,0);e.CompleteDrop(unit);Check(!e.Model.TransferRequired,"Transferência de uma unidade falhou");}
     }
     e.Eye.transform.rotation=Quaternion.Euler(24,0,0);Capture();
     File.WriteAllText("Verificacao-runtime.txt","PASS: player loop ativo; 15 corpos; gravidade/colisão com mesa; pausa; recuperação de queda; exclusão de posse simultânea; pegar/soltar programático; 16 divisões e união via soltura; conservação do total.\nTeste em Play Mode no macOS. Entrada dos controles, vibração e desempenho no Quest ainda não validados fisicamente.\n");
     Debug.Log("ATELIER_RUNTIME_QA_PASS");SessionState.SetBool("AtelierRuntimeQA",false);EditorApplication.isPlaying=false;
    }
    SessionState.SetInt("AtelierPhase",phase+1);
   }catch(Exception ex){File.WriteAllText("Verificacao-runtime.txt","FAIL: "+ex);Debug.LogException(ex);SessionState.SetBool("AtelierRuntimeQA",false);EditorApplication.isPlaying=false;}
  }
  static void Capture(){Canvas.ForceUpdateCanvases();var rt=new RenderTexture(1600,1200,24);var old=RenderTexture.active;e.Eye.targetTexture=rt;e.Eye.Render();RenderTexture.active=rt;var t=new Texture2D(1600,1200,TextureFormat.RGB24,false);t.ReadPixels(new Rect(0,0,1600,1200),0,0);t.Apply();Directory.CreateDirectory("Previews");File.WriteAllBytes("Previews/04-execucao.png",t.EncodeToPNG());e.Eye.targetTexture=null;RenderTexture.active=old;UnityEngine.Object.DestroyImmediate(t);UnityEngine.Object.DestroyImmediate(rt);}
 }
}
